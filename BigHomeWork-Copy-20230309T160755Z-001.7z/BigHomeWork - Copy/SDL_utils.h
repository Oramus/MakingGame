#ifndef SDL_UTILS_H_INCLUDED
#define SDL_UTILS_H_INCLUDED

#include <iostream>
#include <SDL.h>

using namespace std;

const int SCREEN_WIDTH = 1000;
const int SCREEN_HEIGHT = 800;
const string WINDOW_TITLE = "An Implementation of Code.org Painter";

/** Hàm báo lỗi SDL */
void logSDLError(ostream& os, const string &msg, bool fatal = false);

/** Hàm khơi tạo SDL */
void initSDL(SDL_Window* &window, SDL_Renderer* &renderer);

/** Hàm xóa (giải phóng) SDL */
void quitSDL(SDL_Window* window, SDL_Renderer* renderer);

/** Hàm tiện ích: Đợi nhấn phím */
void waitUntilKeyPressed();

/** Hàm nạp texture từ file ảnh, để vẽ lên renderer tương ứng */
SDL_Texture* loadTexture(const std::string &file, SDL_Renderer *ren);

/** Hàm đưa texture ra renderer (để hiển thị ra màn hình) tại toạ độ (x,y) và giữ nguyên kích cỡ ban đầu của ảnh */
void renderTexture(SDL_Texture *tex, SDL_Renderer *ren, int x, int y);

/** Hàm đưa texture ra renderer (để hiển thị ra màn hình) tại toạ độ (x,y) với kích cỡ rộng (w) và cao (h) cho trước */
void renderTexture(SDL_Texture *tex, SDL_Renderer *ren, int x, int y, int w, int h);

#endif // SDL_UTILS_H_INCLUDED
