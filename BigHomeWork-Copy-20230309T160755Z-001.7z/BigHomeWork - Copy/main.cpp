#include <iostream>
#include <SDL.h>
#include "SDL_utils.h"

using namespace std;

void refreshBasket(SDL_Renderer* renderer, SDL_Texture* ship, const SDL_Rect &basket_ship, SDL_Texture* bg);

int main(int argc, char* argv[])
{
    SDL_Window* window;
    SDL_Renderer* renderer;
    initSDL(window, renderer);

    SDL_Event event;
    int step = 10; //bước nhảy mỗi lần dịch chuyển

    SDL_Texture* background = loadTexture("background.bmp", renderer);
    SDL_Texture* ship = loadTexture("ship.bmp", renderer);
    if (background == nullptr || ship == nullptr){
        SDL_DestroyTexture(background);
        SDL_DestroyTexture(ship);
        quitSDL(window, renderer);
    }

    SDL_RenderClear(renderer);

    //Vẽ background trên toàn bộ cửa sổ
    renderTexture(background, renderer, 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);

    //Vẽ ảnh con tàu ở chính giữa màn hình
    int shipW, shipH;
    SDL_QueryTexture(ship, NULL, NULL, &shipW, &shipH);
    SDL_Rect basket_ship;
    basket_ship.x = SCREEN_WIDTH/2 - shipW/4;
    basket_ship.y = SCREEN_HEIGHT/2 - shipH/4;
    basket_ship.w = shipW/2;
    basket_ship.h = shipH/2;

    SDL_RenderCopy(renderer, ship, NULL, &basket_ship);

    SDL_RenderPresent(renderer);

    while (true) {
        // Đợi 10 mili giây
        SDL_Delay(10);

        // Nếu không có sự kiện gì thì tiếp tục trở về đầu vòng lặp
        if ( SDL_WaitEvent(&event) == 0) continue;

        // Nếu sự kiện là kết thúc (như đóng cửa sổ) thì thoát khỏi vòng lặp
        if (event.type == SDL_QUIT) break;

        // Nếu có một phím được nhấn, thì xét phím đó là gì để xử lý tiếp
        if (event.type == SDL_KEYDOWN) {
            // Nếu nhấn phìm ESC thì thoát khỏi vòng lặp
            if (event.key.keysym.sym == SDLK_ESCAPE) break;

            // Nếu phím mũi tên trái, dịch sang trái
            if (event.key.keysym.sym == SDLK_LEFT) basket_ship.x -= step;
            if (event.key.keysym.sym == SDLK_RIGHT) basket_ship.x += step;

            // Tương tự với dịch phải, xuống và lên
            if (event.key.keysym.sym == SDLK_UP) basket_ship.y -= step;
            if (event.key.keysym.sym == SDLK_DOWN) basket_ship.y += step;

            // Xoá toàn ảnh cái rổ và vẽ lại
            refreshBasket(renderer, ship, basket_ship, background);
        }
    }

    waitUntilKeyPressed();
    SDL_DestroyTexture(background);
    SDL_DestroyTexture(ship);
    quitSDL(window, renderer);
    return 0;
}

void refreshBasket(SDL_Renderer* renderer, SDL_Texture* ship, const SDL_Rect &basket_ship, SDL_Texture* bg)
{
    SDL_RenderClear(renderer);
    renderTexture(bg, renderer, 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    SDL_RenderCopy(renderer, ship, NULL, &basket_ship);
    SDL_RenderPresent(renderer);
}
